
package BackEnd;

/**
 *
 * @author Utilizador
 */
public enum EstadoPedido {
    
    APROVADO,
    PENDENTE,
    RECUSADO;
}
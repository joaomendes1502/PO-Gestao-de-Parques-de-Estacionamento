
package BackEnd;


public enum TipoParque {
    LIVRE,
    CONDICIONADO,
    LUGAR_ASSEGURADO
}


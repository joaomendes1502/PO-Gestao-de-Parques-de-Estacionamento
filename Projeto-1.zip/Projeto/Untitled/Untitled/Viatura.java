package Untitled;

public class Viatura {

	private String matricula;
	private String combustivel;
	private String modelo;
	private String marca;

}

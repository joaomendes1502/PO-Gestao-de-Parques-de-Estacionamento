package Untitled;

public class ListaViaturas {

	private HashMap <String,Viatura> listaViaturas;

}

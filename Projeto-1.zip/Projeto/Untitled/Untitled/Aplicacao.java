package Untitled;

public class Aplicacao {

	private ListaUtilizador listaUtilizador;
	private ListaViaturas listaViaturas;
	private ListaParques listaParques;
	private ListaPedidos listaPedidos;
	private ListControlo listaControlo;

}

package Untitled;

public class Parque {

	private String tipo;
	private float preco;
	private String nome;
	private int numLugares;

}

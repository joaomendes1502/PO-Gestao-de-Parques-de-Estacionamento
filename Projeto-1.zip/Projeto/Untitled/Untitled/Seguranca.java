package Untitled;

public class Seguranca extends Utilizador {

}

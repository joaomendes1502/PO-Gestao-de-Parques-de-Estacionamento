package Untitled;

public class ListaPedidos {

	private ArrayList<PedidoAcesso> listaPedidos;

}

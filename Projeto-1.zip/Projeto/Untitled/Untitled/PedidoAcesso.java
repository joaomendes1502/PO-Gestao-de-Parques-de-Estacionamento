package Untitled;

public class PedidoAcesso {

	private Parque parque;
	private Utente utente;
	private String estado;

}

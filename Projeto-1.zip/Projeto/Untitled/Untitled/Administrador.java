package Untitled;

public class Administrador extends Utilizador {

}

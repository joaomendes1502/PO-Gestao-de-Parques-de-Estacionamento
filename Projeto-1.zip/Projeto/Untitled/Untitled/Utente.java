package Untitled;

public class Utente extends Utilizador {

	private Viatura viatura;

}

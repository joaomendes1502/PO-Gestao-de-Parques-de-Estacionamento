package Untitled;

public class ListaUtilizador {

	private HashMap<String,Utilizador> listaUtilizador;

}

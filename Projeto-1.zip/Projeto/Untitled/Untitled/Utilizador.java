package Untitled;

public class Utilizador {

	private String username;
	private String password;
	private String nome;

}

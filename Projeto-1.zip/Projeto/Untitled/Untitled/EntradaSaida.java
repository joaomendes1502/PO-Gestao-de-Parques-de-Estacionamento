package Untitled;

public class EntradaSaida {

	private LocalDate dataEntrada;
	private LocalDate dataSaida;
	private Viatura viatura;
	private Parque parque;
	private LocalDate horaEntrada;
	private LocalDate horaSaida;

}

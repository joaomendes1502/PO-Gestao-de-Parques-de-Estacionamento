package Untitled;

public class ListaControlo {

	private ArrayList <Viatura> listaControlo;

}

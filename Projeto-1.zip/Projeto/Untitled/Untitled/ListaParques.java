package Untitled;

public class ListaParques {

	private ArrayList<Parque> listaParques;

}
